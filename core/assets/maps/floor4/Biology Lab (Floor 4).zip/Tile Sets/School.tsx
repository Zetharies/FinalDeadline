<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="School" tilewidth="32" tileheight="32" tilecount="135" columns="9">
 <image source="../Images/School.png" width="289" height="480"/>
</tileset>
