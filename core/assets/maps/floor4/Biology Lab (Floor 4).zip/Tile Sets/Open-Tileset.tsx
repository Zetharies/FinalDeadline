<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="Open-Tileset" tilewidth="32" tileheight="32" tilecount="616" columns="22">
 <image source="../Images/Open-Tileset.png" width="708" height="908"/>
 <tile id="18">
  <properties>
   <property name="Blocked" value="true"/>
  </properties>
 </tile>
</tileset>
