<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="School-General" tilewidth="32" tileheight="32" tilecount="252" columns="18">
 <image source="../Images/School-General.png" width="576" height="450"/>
</tileset>
