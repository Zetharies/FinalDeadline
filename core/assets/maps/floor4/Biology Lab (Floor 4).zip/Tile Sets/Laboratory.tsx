<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="Laboratory" tilewidth="32" tileheight="32" tilecount="360" columns="35">
 <image source="../Images/Laboratory.png" width="1136" height="304"/>
</tileset>
